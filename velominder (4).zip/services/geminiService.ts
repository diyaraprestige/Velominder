
import { GoogleGenAI, Type } from "@google/genai";

// Use process.env.API_KEY directly inside each function as per GenAI SDK guidelines.

export const getVehicleMaintenanceAdvice = async (type: string, brand: string, model: string, year: number, mileage: number, extraInfo?: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const prompt = `Act as a senior automotive and motorcycle engineer specialized in the Southeast Asian market (especially Malaysia). 
  Provide a detailed maintenance schedule and oil recommendation for a ${year} ${brand} ${model} (${type}) at ${mileage} km. 
  ${extraInfo ? `Context: ${extraInfo}` : ''}
  Address tropical climate concerns. Include:
  1. Recommended engine oil viscosity and specifications (e.g., JASO MA2 for manual bikes, JASO MB for scooters, or car specs).
  2. Transmission/Gearbox oil type and change interval.
  3. Drive system maintenance (e.g., chain lube/tension for bikes, CVT belt for scooters, or car specific items).
  4. Specific wear and tear items to check for this specific model in Malaysia.
  Keep it technical yet readable.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Advice Error:", error);
    return "Advice currently unavailable.";
  }
};

export const getSmartMaintenanceItems = async (type: string, brand: string, model: string, year: number, extraInfo?: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Generate a JSON array of standard maintenance items for a ${year} ${brand} ${model} (${type}). 
      ${extraInfo ? `Context: ${extraInfo}` : ''}
      Focus on long-term reliability in Malaysia. Each item must have: name, intervalKm (number), category (engine, transmission, suspension, braking, general, drive), and importance (critical, normal, low).`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              intervalKm: { type: Type.NUMBER },
              category: { type: Type.STRING },
              importance: { type: Type.STRING },
            },
            required: ["name", "intervalKm", "category", "importance"]
          }
        }
      }
    });
    return JSON.parse(response.text || '[]');
  } catch (e) {
    return null;
  }
};

export const getNearbyWorkshops = async (lat: number, lng: number, brand: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Find highly-rated car workshops or ${brand} service centers nearby.`,
      config: {
        tools: [{ googleMaps: {} }],
        toolConfig: {
          retrievalConfig: {
            latLng: { latitude: lat, longitude: lng }
          }
        }
      },
    });
    
    // Extract grounding chunks for links as per Maps Grounding rule.
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    return {
      text: response.text,
      links: chunks.filter(c => c.maps).map(c => ({
        title: c.maps?.title,
        uri: c.maps?.uri,
        // Includes placeAnswerSources if available as per requirement.
        reviewSnippets: c.maps?.placeAnswerSources?.reviewSnippets
      }))
    };
  } catch (e) {
    console.error("Maps Error:", e);
    return null;
  }
};

export const getOwnershipTips = async (carDesc: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Provide 3 unique car maintenance tips for a ${carDesc} owner to save money and extend vehicle life. Use bullet points.`,
      config: { tools: [{ googleSearch: {} }] }
    });
    
    // Extract grounding chunks for search results as per Search Grounding rule.
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    return {
      text: response.text,
      links: chunks.filter(c => c.web).map(c => ({
        title: c.web?.title,
        uri: c.web?.uri
      }))
    };
  } catch (e) {
    return null;
  }
};
