
import { OilType, OilProfile } from './types';

export const OIL_PROFILES: Record<OilType, OilProfile> = {
  [OilType.MIN_15W40]: {
    type: 'Mineral',
    intervalKm: 5000,
    description: 'Standard mineral protection for older or high-mileage car engines.'
  },
  [OilType.MIN_20W50]: {
    type: 'Mineral',
    intervalKm: 5000,
    description: 'Thicker viscosity for vintage car engines or those with slight oil leaks.'
  },
  [OilType.SEMI_10W30]: {
    type: 'Semi-Synthetic',
    intervalKm: 7000,
    description: 'Improved flow and protection balance for modern daily car drivers.'
  },
  [OilType.SEMI_10W40]: {
    type: 'Semi-Synthetic',
    intervalKm: 7000,
    description: 'The standard choice for most modern cars in tropical climates.'
  },
  [OilType.FULL_0W20]: {
    type: 'Fully Synthetic',
    intervalKm: 10000,
    description: 'Max fuel efficiency and flow for newer fuel-efficient car engines.'
  },
  [OilType.FULL_5W30]: {
    type: 'Fully Synthetic',
    intervalKm: 10000,
    description: 'High performance protection with excellent temperature stability.'
  },
  [OilType.FULL_5W40]: {
    type: 'Fully Synthetic',
    intervalKm: 10000,
    description: 'Ultimate protection for performance or turbocharged car engines.'
  },
  [OilType.MOTO_MIN_20W50]: {
    type: 'Moto Mineral',
    intervalKm: 1500,
    description: 'Basic protection for older kapchais or carbureted bikes.'
  },
  [OilType.MOTO_SEMI_10W40]: {
    type: 'Moto Semi-Synthetic',
    intervalKm: 3000,
    description: 'Balanced protection for modern fuel-injected motorcycles.'
  },
  [OilType.MOTO_FULL_10W40]: {
    type: 'Moto Fully Synthetic',
    intervalKm: 5000,
    description: 'High-performance protection for sport and touring bikes.'
  },
  [OilType.MOTO_FULL_10W50]: {
    type: 'Moto Fully Synthetic',
    intervalKm: 5000,
    description: 'Maximum protection for high-heat or high-revving engines.'
  },
  [OilType.SCOOTER_SEMI_10W40]: {
    type: 'Scooter Semi-Synthetic',
    intervalKm: 3000,
    description: 'Low friction oil specifically for automatic scooter engines (JASO MB).'
  },
  [OilType.SCOOTER_FULL_10W30]: {
    type: 'Scooter Fully Synthetic',
    intervalKm: 5000,
    description: 'Premium protection for modern high-performance scooters.'
  }
};

export const CAR_BRANDS = [
  'Proton', 'Perodua', 'Toyota', 'Honda', 'Nissan', 'Mazda', 'BMW', 
  'Mercedes-Benz', 'Audi', 'Volkswagen', 'Ford', 'Chevrolet', 'Hyundai', 
  'Kia', 'Subaru', 'Lexus', 'Volvo', 'Porsche', 'Mitsubishi', 'Isuzu', 'Chery'
].sort();

export const MOTO_BRANDS = [
  'Yamaha', 'Honda', 'Kawasaki', 'Suzuki', 'Modenas', 'Benelli', 'Sym', 
  'KTM', 'BMW', 'Ducati', 'Harley-Davidson', 'Triumph', 'Vespa', 'Aprilia', 
  'Royal Enfield', 'Kymco', 'Wmoto', 'Aveta', 'Zontes'
].sort();

export const DEFAULT_MAINTENANCE: any[] = [
  { name: 'Engine Oil Filter', intervalKm: 10000, category: 'engine', importance: 'critical' },
  { name: 'Gearbox Oil (ATF/CVT)', intervalKm: 40000, category: 'transmission', importance: 'critical' },
  { name: 'Brake Pads', intervalKm: 30000, category: 'braking', importance: 'critical' },
  { name: 'Spark Plugs', intervalKm: 40000, category: 'engine', importance: 'normal' },
  { name: 'Air Filter', intervalKm: 20000, category: 'engine', importance: 'normal' },
  { name: 'Cabin Filter', intervalKm: 20000, category: 'general', importance: 'low' },
  { name: 'Timing Belt/Chain', intervalKm: 100000, category: 'engine', importance: 'critical' },
  { name: 'Coolant Flush', intervalKm: 50000, category: 'engine', importance: 'normal' },
  { name: 'Power Steering Fluid', intervalKm: 60000, category: 'general', importance: 'normal' },
  { name: 'Brake Fluid', intervalKm: 40000, category: 'braking', importance: 'critical' },
  { name: 'Wiper Blades', intervalKm: 15000, category: 'general', importance: 'low' },
  { name: 'Battery', intervalKm: 60000, category: 'general', importance: 'critical' }
];

export const MOTO_DEFAULT_MAINTENANCE: any[] = [
  { name: 'Oil Filter', intervalKm: 5000, category: 'engine', importance: 'critical' },
  { name: 'Drive Chain Cleaning & Lube', intervalKm: 500, category: 'drive', importance: 'normal' },
  { name: 'Drive Chain Tension Adjustment', intervalKm: 1000, category: 'drive', importance: 'critical' },
  { name: 'Sprocket Set', intervalKm: 20000, category: 'drive', importance: 'normal' },
  { name: 'CVT Belt (Scooter)', intervalKm: 20000, category: 'drive', importance: 'critical' },
  { name: 'CVT Rollers (Scooter)', intervalKm: 20000, category: 'drive', importance: 'normal' },
  { name: 'Gear Oil (Scooter)', intervalKm: 10000, category: 'transmission', importance: 'critical' },
  { name: 'Spark Plug', intervalKm: 10000, category: 'engine', importance: 'normal' },
  { name: 'Air Filter', intervalKm: 10000, category: 'engine', importance: 'normal' },
  { name: 'Brake Pads/Shoes', intervalKm: 10000, category: 'braking', importance: 'critical' },
  { name: 'Brake Fluid', intervalKm: 20000, category: 'braking', importance: 'critical' },
  { name: 'Coolant Flush', intervalKm: 20000, category: 'engine', importance: 'normal' },
  { name: 'Valve Clearance', intervalKm: 20000, category: 'engine', importance: 'normal' },
  { name: 'Fork Oil', intervalKm: 30000, category: 'suspension', importance: 'low' },
  { name: 'Battery', intervalKm: 24000, category: 'general', importance: 'critical' }
];
