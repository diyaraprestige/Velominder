
import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { OilType, Vehicle, MaintenanceItem, MaintenanceLog, VehicleType, MotorcycleType } from './types';
import { OIL_PROFILES, CAR_BRANDS, MOTO_BRANDS, DEFAULT_MAINTENANCE, MOTO_DEFAULT_MAINTENANCE } from './constants';
import { getVehicleMaintenanceAdvice, getSmartMaintenanceItems } from './services/geminiService';
import { 
  Wrench, 
  Droplet, 
  Plus, 
  AlertCircle, 
  Calendar, 
  Gauge,
  History,
  Car as CarIcon,
  Bike,
  BrainCircuit,
  Loader2,
  Trash2,
  ChevronDown,
  Info,
  Scale,
  ChevronLeft,
  ChevronRight,
  Download,
  CheckCircle2,
  CloudSync,
  LogOut,
  X,
  Mail,
  ShieldCheck,
  Smartphone,
  ChevronRight as ChevronRightIcon,
  User,
  Settings
} from 'lucide-react';

const App: React.FC = () => {
  const [isInitializing, setIsInitializing] = useState(true);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [syncStatus, setSyncStatus] = useState<'synced' | 'syncing' | 'error'>('synced');
  const [toasts, setToasts] = useState<{ id: string; message: string; type: 'success' | 'info' }[]>([]);

  // --- Persistent State ---
  const [user, setUser] = useState<{ name: string; email: string; picture?: string; provider?: string } | null>(() => {
    try {
      const saved = localStorage.getItem('auto_track_user');
      return saved ? JSON.parse(saved) : null;
    } catch (e) { return null; }
  });

  const [cars, setCars] = useState<Vehicle[]>(() => {
    try {
      const saved = localStorage.getItem('auto_track_cars');
      return saved ? JSON.parse(saved) : [];
    } catch (e) { return []; }
  });
  
  const [activeCarId, setActiveCarId] = useState<string | null>(() => {
    return localStorage.getItem('auto_track_active_id');
  });

  const [logs, setLogs] = useState<MaintenanceLog[]>(() => {
    try {
      const saved = localStorage.getItem('auto_track_logs');
      return saved ? JSON.parse(saved) : [];
    } catch (e) { return []; }
  });

  // --- UI State ---
  const [aiAdvice, setAiAdvice] = useState<string | null>(null);
  const [loadingAdvice, setLoadingAdvice] = useState(false);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'items' | 'history'>('dashboard');
  const [showAddLog, setShowAddLog] = useState(false);
  const [showUpdateMileage, setShowUpdateMileage] = useState(false);
  const [showAddCar, setShowAddCar] = useState(false);
  const [showGarage, setShowGarage] = useState(false);
  const [showPrivacy, setShowPrivacy] = useState(false);
  const [showServiceCalendar, setShowServiceCalendar] = useState(false);

  // --- Persistence Engine ---
  const saveToStorage = useCallback(() => {
    setSyncStatus('syncing');
    try {
      localStorage.setItem('auto_track_cars', JSON.stringify(cars));
      localStorage.setItem('auto_track_logs', JSON.stringify(logs));
      localStorage.setItem('auto_track_user', JSON.stringify(user));
      if (activeCarId) localStorage.setItem('auto_track_active_id', activeCarId);
      // Visual debounce for sync indicator
      setTimeout(() => setSyncStatus('synced'), 600);
    } catch (e) {
      setSyncStatus('error');
    }
  }, [cars, logs, activeCarId, user]);

  useEffect(() => {
    if (!isInitializing) {
      saveToStorage();
    }
  }, [saveToStorage, isInitializing]);

  useEffect(() => {
    const handleUnload = () => {
      localStorage.setItem('auto_track_cars', JSON.stringify(cars));
      localStorage.setItem('auto_track_logs', JSON.stringify(logs));
    };
    window.addEventListener('beforeunload', handleUnload);
    return () => window.removeEventListener('beforeunload', handleUnload);
  }, [cars, logs]);

  const addToast = (message: string, type: 'success' | 'info' = 'success') => {
    const id = crypto.randomUUID();
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 3000);
  };

  useEffect(() => {
    const timer = setTimeout(() => setIsInitializing(false), 3000);
    
    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    return () => {
      clearTimeout(timer);
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const activeCar = useMemo(() => 
    cars.find(c => c.id === activeCarId) || (cars.length > 0 ? cars[0] : null)
  , [cars, activeCarId]);

  useEffect(() => {
    if (activeCar && activeCar.id !== activeCarId) setActiveCarId(activeCar.id);
  }, [activeCar, activeCarId]);

  const handleInstallApp = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') setDeferredPrompt(null);
  };

  const handleLoginSuccess = (response: any) => {
    try {
      const base64Url = response.credential.split('.')[1];
      const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
      const jsonPayload = decodeURIComponent(atob(base64).split('').map(c => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2)).join(''));
      const payload = JSON.parse(jsonPayload);

      setUser({
        name: payload.name,
        email: payload.email,
        picture: payload.picture,
        provider: 'google'
      });
      addToast(`Logged in as ${payload.given_name}`);
    } catch (e) {
      addToast("Login failed", "info");
    }
  };

  const handleEmailLogin = (email: string) => {
    setUser({
      name: email.split('@')[0],
      email: email,
      provider: 'email'
    });
    addToast("Logged in with Email");
  };

  const fetchAiInsights = useCallback(async () => {
    if (!activeCar) return;
    setLoadingAdvice(true);
    try {
      const extraInfo = activeCar.type === VehicleType.MOTORCYCLE 
        ? `${activeCar.motorcycleType} ${activeCar.engineCapacity}cc ${activeCar.isCarbureted ? 'Carbureted' : 'Fuel Injected'}`
        : '';
      const advice = await getVehicleMaintenanceAdvice(activeCar.type, activeCar.brand, activeCar.model, activeCar.year, activeCar.currentMileage, extraInfo);
      setAiAdvice(advice);
    } catch (e) {
      addToast("AI analysis unavailable", "info");
    } finally {
      setLoadingAdvice(false);
    }
  }, [activeCar]);

  const handleAddCar = (newCar: Vehicle) => {
    setCars(prev => [...prev, newCar]);
    setActiveCarId(newCar.id);
    setShowAddCar(false);
    addToast(`${newCar.model} Registered!`);
  };

  const deleteCar = (id: string) => {
    if (confirm("Delete this vehicle and its entire history?")) {
      setCars(prev => {
        const updated = prev.filter(c => c.id !== id);
        if (activeCarId === id) setActiveCarId(updated.length > 0 ? updated[0].id : null);
        return updated;
      });
      setLogs(prev => prev.filter(l => l.vehicleId !== id));
      addToast("Car removed.");
    }
  };

  const addLogEntry = (logData: Partial<MaintenanceLog>) => {
    if (!activeCar) return;
    const logMileage = logData.mileage || activeCar.currentMileage;
    const newLog: MaintenanceLog = {
      id: crypto.randomUUID(),
      vehicleId: activeCar.id,
      date: logData.date || new Date().toISOString().split('T')[0],
      time: logData.time || new Date().toTimeString().slice(0, 5),
      mileage: logMileage,
      description: logData.description || 'Service record',
      itemsChanged: logData.itemsChanged || [],
      workshopName: logData.workshopName
    };

    setLogs(prev => [newLog, ...prev]);
    setCars(prev => prev.map(c => {
      if (c.id === activeCar.id) {
        const isOilChange = newLog.itemsChanged.some(item => item.toLowerCase().includes('oil'));
        return {
          ...c,
          currentMileage: Math.max(c.currentMileage, logMileage),
          lastOilChangeMileage: isOilChange ? Math.max(c.lastOilChangeMileage, logMileage) : c.lastOilChangeMileage,
          maintenanceItems: c.maintenanceItems.map(item => 
            newLog.itemsChanged.includes(item.name) 
              ? { ...item, lastChangedMileage: logMileage } 
              : item
          )
        };
      }
      return c;
    }));
    setShowAddLog(false);
    setActiveTab('history');
    addToast("Key-in successful!");
  };

  const suggestions = useMemo(() => {
    if (!activeCar) return [];
    const overdue: string[] = [];
    const oilLimit = OIL_PROFILES[activeCar.oilType].intervalKm;
    if ((activeCar.currentMileage - activeCar.lastOilChangeMileage) >= oilLimit) overdue.push('Engine Oil');
    activeCar.maintenanceItems.forEach(item => {
      if ((activeCar.currentMileage - item.lastChangedMileage) >= item.intervalKm) overdue.push(item.name);
    });
    return overdue;
  }, [activeCar]);

  if (isInitializing) return <SplashScreen />;
  if (!user) return <LandingPage onLoginSuccess={handleLoginSuccess} onEmailLogin={handleEmailLogin} onShowPolicy={() => setShowPrivacy(true)} />;
  if (showAddCar || (user && cars.length === 0)) return <Onboarding onComplete={handleAddCar} onCancel={cars.length > 0 ? () => setShowAddCar(false) : undefined} />;
  if (!activeCar) return null;

  const oilLimit = OIL_PROFILES[activeCar.oilType]?.intervalKm || 10000;
  const oilUsed = activeCar.currentMileage - activeCar.lastOilChangeMileage;
  const oilHealth = Math.max(0, Math.min(100, (1 - oilUsed / oilLimit) * 100));

  return (
    <div className="h-full flex flex-col bg-slate-50 overflow-hidden animate-in fade-in duration-700">
      <header className="pt-12 px-6 pb-6 bg-white border-b border-slate-100 shadow-sm flex-shrink-0">
        <div className="flex items-center justify-between">
          <button onClick={() => setShowGarage(true)} className="flex items-center gap-4 group">
            <div className="w-12 h-12 rounded-2xl bg-indigo-600 flex items-center justify-center text-white shadow-lg shadow-indigo-100 relative">
               {user.picture ? <img src={user.picture} className="w-full h-full rounded-2xl object-cover" /> : <div className="font-black text-lg">{user.name[0].toUpperCase()}</div>}
               <div className={`absolute -top-1 -right-1 w-3 h-3 rounded-full border-2 border-white transition-colors duration-500 ${syncStatus === 'synced' ? 'bg-emerald-500' : syncStatus === 'syncing' ? 'bg-amber-500 animate-pulse shadow-[0_0_8px_#f59e0b]' : 'bg-red-500'}`}></div>
            </div>
            <div className="text-left">
              <p className="text-[10px] font-black text-indigo-500 uppercase tracking-widest flex items-center gap-1">
                {activeCar.plateNumber}
                {syncStatus === 'synced' ? <CheckCircle2 className="w-3 h-3" /> : <CloudSync className="w-3 h-3 animate-spin" />}
              </p>
              <div className="flex items-center gap-1">
                <h1 className="text-xl font-extrabold text-slate-900 leading-tight truncate max-w-[150px]">{activeCar.model}</h1>
                <ChevronDown className="w-4 h-4 text-slate-400 group-active:rotate-180 transition-transform" />
              </div>
            </div>
          </button>
          <button onClick={() => setShowAddLog(true)} className="w-10 h-10 rounded-full bg-slate-900 text-white flex items-center justify-center shadow-lg active:scale-95 transition-transform"><Plus className="w-6 h-6" /></button>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto hide-scrollbar p-6 pb-32 space-y-6">
        {activeTab === 'dashboard' && (
          <>
            <section className="bg-white p-6 rounded-[2rem] shadow-sm border border-slate-100">
              <div className="flex justify-between items-start mb-4">
                <div className="p-3 bg-slate-50 rounded-2xl"><Gauge className="w-6 h-6 text-slate-400" /></div>
                <button onClick={() => setShowUpdateMileage(true)} className="px-4 py-2 bg-slate-900 text-white rounded-full text-[10px] font-black uppercase tracking-wider shadow-md active:scale-95">Key-in Odo</button>
              </div>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Live Mileage</p>
              <h2 className="text-4xl font-black text-slate-900 tabular-nums">{activeCar.currentMileage.toLocaleString()}<span className="text-sm font-bold text-slate-300 ml-2 uppercase">KM</span></h2>
            </section>

            <section className={`bg-white p-6 rounded-[2rem] shadow-sm border transition-all duration-700 ${oilHealth >= 100 ? 'emerald-glow border-emerald-500/20' : 'border-slate-100'}`}>
              <div className="flex justify-between items-center mb-6">
                <div><h3 className="text-lg font-black text-slate-900">Oil Lifespan</h3><p className="text-xs font-bold text-indigo-500 uppercase tracking-tighter">{activeCar.oilType}</p></div>
                <div className={`p-3 rounded-2xl ${oilHealth >= 100 ? 'bg-emerald-50 text-emerald-600' : oilHealth > 20 ? 'bg-indigo-50 text-indigo-600' : 'bg-red-50 text-red-600'}`}><Droplet className="w-6 h-6" /></div>
              </div>
              <div className="flex justify-between items-end mb-3">
                <span className={`text-4xl font-black ${oilHealth >= 100 ? 'text-emerald-600' : oilHealth > 20 ? 'text-slate-900' : 'text-red-600'}`}>{Math.round(oilHealth)}%</span>
                <p className="text-[10px] font-bold text-slate-400 uppercase pb-1">Due at: {(activeCar.lastOilChangeMileage + oilLimit).toLocaleString()} km</p>
              </div>
              <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
                <div className={`h-full transition-all duration-1000 ${oilHealth >= 100 ? 'bg-emerald-500' : oilHealth > 50 ? 'bg-indigo-500' : oilHealth > 20 ? 'bg-orange-500' : 'bg-red-500'}`} style={{ width: `${oilHealth}%` }} />
              </div>
            </section>

            <section className="bg-slate-900 p-8 rounded-[2.5rem] text-white shadow-xl relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-125 transition-transform duration-700"><BrainCircuit className="w-32 h-32" /></div>
              <div className="relative z-10">
                <div className="flex items-center gap-3 mb-6">
                  <div className="p-2 bg-white/10 rounded-xl"><BrainCircuit className="w-6 h-6 text-indigo-400" /></div>
                  <h3 className="text-xl font-black uppercase tracking-tight">AI Diagnostic</h3>
                </div>
                {aiAdvice ? (
                  <div className="space-y-4">
                     <div className="text-sm font-medium leading-relaxed opacity-90">{aiAdvice}</div>
                     <button onClick={fetchAiInsights} className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-black text-sm uppercase">Re-Analyze</button>
                  </div>
                ) : (
                  <div className="text-center py-4">
                    <p className="text-slate-400 text-sm font-medium mb-6">Evaluate engine health using Gemini AI automotive engine.</p>
                    <button onClick={fetchAiInsights} disabled={loadingAdvice} className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-black text-sm uppercase flex items-center justify-center gap-2 active:scale-95 transition-transform">
                      {loadingAdvice ? <Loader2 className="animate-spin w-5 h-5" /> : 'Start AI Audit'}
                    </button>
                  </div>
                )}
              </div>
            </section>
          </>
        )}

        {activeTab === 'items' && (
          <div className="space-y-4 pb-12">
            <div className="flex items-center justify-between px-1">
              <h3 className="text-2xl font-black text-slate-900 uppercase">Health Check</h3>
              <button onClick={() => setShowServiceCalendar(true)} className="w-10 h-10 bg-white border border-slate-100 shadow-sm rounded-xl flex items-center justify-center text-indigo-600"><Calendar className="w-5 h-5" /></button>
            </div>
            <MaintenanceCard name="Engine Oil" category="engine" intervalKm={oilLimit} lastChangedMileage={activeCar.lastOilChangeMileage} currentMileage={activeCar.currentMileage} />
            {activeCar.maintenanceItems.map(item => (
              <MaintenanceCard key={item.id} {...item} currentMileage={activeCar.currentMileage} />
            ))}
          </div>
        )}

        {activeTab === 'history' && (
          <div className="space-y-6">
             <h3 className="text-2xl font-black text-slate-900 uppercase px-1">Garage Logs</h3>
             <div className="space-y-4">
                {logs.filter(l => l.vehicleId === activeCar.id).length === 0 ? (
                  <div className="text-center py-24 opacity-30"><History className="w-16 h-16 mx-auto mb-4" /><p className="font-black uppercase tracking-[0.2em] text-xs">No entries found</p></div>
                ) : logs.filter(l => l.vehicleId === activeCar.id).map(log => (
                  <div key={log.id} className="bg-white p-6 rounded-[2rem] shadow-sm border border-slate-100 animate-in slide-in-from-bottom duration-500">
                    <div className="flex justify-between items-start mb-4">
                      <div><h4 className="text-xl font-black text-slate-900">{log.mileage.toLocaleString()} km</h4><div className="flex gap-3 text-[10px] font-bold text-slate-400 uppercase mt-1"><span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {log.date}</span></div></div>
                    </div>
                    <p className="text-sm text-slate-600 mb-4 font-medium italic">"{log.description}"</p>
                    <div className="flex flex-wrap gap-2">{log.itemsChanged.map(item => <span key={item} className="px-3 py-1 bg-slate-900 text-white text-[9px] font-black uppercase rounded-lg">{item}</span>)}</div>
                  </div>
                ))}
             </div>
          </div>
        )}
      </main>

      {/* Toast System */}
      <div className="fixed top-20 left-0 right-0 z-[500] px-6 pointer-events-none flex flex-col gap-2">
        {toasts.map(toast => (
          <div key={toast.id} className="bg-slate-900 text-white px-6 py-4 rounded-2xl shadow-2xl text-[10px] font-black uppercase tracking-widest flex items-center gap-3 animate-in slide-in-from-top duration-300 mx-auto border border-white/10">
            <div className="w-6 h-6 bg-emerald-500 rounded-full flex items-center justify-center"><CheckCircle2 className="w-4 h-4 text-white" /></div>
            {toast.message}
          </div>
        ))}
      </div>

      <nav className="flex-shrink-0 bg-white/80 backdrop-blur-xl border-t border-slate-200 p-4 pb-8 flex justify-around items-center safe-bottom">
        <TabButton active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')} icon={<Gauge />} label="Home" />
        <TabButton active={activeTab === 'items'} onClick={() => setActiveTab('items')} icon={<Wrench />} label="Service" />
        <TabButton active={activeTab === 'history'} onClick={() => setActiveTab('history')} icon={<History />} label="Logs" />
      </nav>

      {showUpdateMileage && <UpdateMileageModal car={activeCar} suggestionsCount={suggestions.length} onUpdate={(val) => {
        setCars(prev => prev.map(c => c.id === activeCar.id ? { ...c, currentMileage: val } : c));
        setShowUpdateMileage(false);
        addToast("Mileage Synced!");
      }} onCancel={() => setShowUpdateMileage(false)} />}
      {showAddLog && <AddLogModal car={activeCar} suggestions={suggestions} onAdd={addLogEntry} onCancel={() => setShowAddLog(false)} />}
      {showGarage && <GarageModal user={user} cars={cars} activeCarId={activeCarId} canInstall={!!deferredPrompt} onInstall={handleInstallApp} onSelect={(id) => { setActiveCarId(id); setShowGarage(false); }} onDelete={deleteCar} onAdd={() => { setShowAddCar(true); setShowGarage(false); }} onCancel={() => setShowGarage(false)} onSignOut={() => { setUser(null); localStorage.clear(); window.location.reload(); }} onShowPolicy={() => { setShowPrivacy(true); setShowGarage(false); }} />}
      {showPrivacy && <PrivacyPolicyModal onCancel={() => setShowPrivacy(false)} />}
      {showServiceCalendar && activeCar && <ServiceCalendarModal logs={logs.filter(l => l.vehicleId === activeCar.id)} onClose={() => setShowServiceCalendar(false)} />}
    </div>
  );
};

// --- Branding & UI Elements ---

const Logo = ({ className = "w-16 h-16" }: { className?: string }) => (
  <div className={`bg-indigo-600 rounded-[2rem] flex items-center justify-center text-white shadow-2xl ${className}`}>
     <ShieldCheck className="w-1/2 h-1/2" />
  </div>
);

const SplashScreen = () => (
  <div className="h-full bg-slate-900 flex flex-col items-center justify-center p-8 overflow-hidden">
    <div className="relative mb-12">
      <div className="w-32 h-32 bg-indigo-600 rounded-[3rem] flex items-center justify-center shadow-[0_0_50px_rgba(79,70,229,0.4)] animate-[pulse_2s_infinite]">
        <CarIcon className="w-16 h-16 text-white" />
      </div>
      <div className="absolute -bottom-4 -right-4 w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-lg animate-spin-slow">
        <Settings className="w-6 h-6 text-indigo-600" />
      </div>
    </div>
    <div className="text-center space-y-2">
      <h1 className="text-4xl font-black text-white uppercase tracking-tighter">Velominder</h1>
      <div className="flex flex-col items-center">
        <p className="text-indigo-400 text-[10px] font-black uppercase tracking-[0.4em] mb-8">Precision Tracking</p>
        <div className="flex items-center gap-2 px-4 py-2 bg-white/5 rounded-full border border-white/10">
          <Loader2 className="w-3 h-3 text-indigo-500 animate-spin" />
          <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Securing local vault...</span>
        </div>
      </div>
    </div>
    <style>{`
      @keyframes spin-slow { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      .animate-spin-slow { animation: spin-slow 8s linear infinite; }
    `}</style>
  </div>
);

const LandingPage = ({ onLoginSuccess, onEmailLogin, onShowPolicy }: { onLoginSuccess: (res: any) => void, onEmailLogin: (email: string) => void, onShowPolicy: () => void }) => {
  const [showEmailForm, setShowEmailForm] = useState(false);
  const [email, setEmail] = useState('');

  useEffect(() => {
    const google = (window as any).google;
    if (google) {
      google.accounts.id.initialize({
        client_id: "PLACEHOLDER_CLIENT_ID.apps.googleusercontent.com",
        callback: onLoginSuccess,
        use_fedcm_for_prompt: false 
      });
      google.accounts.id.renderButton(
        document.getElementById("googleBtn"),
        { theme: "outline", size: "large", width: 320, shape: "pill", text: "continue_with" }
      );
    }
  }, [onLoginSuccess]);

  if (showEmailForm) {
    return (
      <div className="h-full bg-white flex flex-col p-8 animate-in slide-in-from-right duration-500">
        <button onClick={() => setShowEmailForm(false)} className="self-start p-3 bg-slate-50 rounded-2xl mb-12"><ChevronLeft className="w-6 h-6" /></button>
        <div className="mb-12">
          <h2 className="text-3xl font-black text-slate-900 tracking-tighter uppercase mb-2">Registration</h2>
          <p className="text-slate-400 font-bold text-xs uppercase tracking-widest">Enter your email to create a vault</p>
        </div>
        <div className="space-y-6 flex-1">
          <div>
            <label className="label">Your Email Address</label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300" />
              <input type="email" value={email} onChange={e => setEmail(e.target.value)} className="input pl-12" placeholder="name@domain.my" autoFocus />
            </div>
          </div>
          <button onClick={() => email && onEmailLogin(email)} className="w-full py-5 bg-indigo-600 text-white rounded-[1.5rem] font-black uppercase text-sm shadow-xl shadow-indigo-100 flex items-center justify-center gap-3 active:scale-95 transition-transform">
            Initialize Account <ChevronRightIcon className="w-5 h-5" />
          </button>
        </div>
        <p className="text-[10px] text-center text-slate-300 font-bold uppercase tracking-widest px-8">Your data remains on this device until cloud sync is activated.</p>
      </div>
    );
  }

  return (
    <div className="h-full bg-white flex flex-col p-8 animate-in fade-in duration-1000">
      <div className="flex-1 flex flex-col items-center justify-center text-center">
        <Logo className="w-24 h-24 mb-10" />
        <h2 className="text-4xl font-black text-slate-900 leading-[0.9] tracking-tighter">Velominder.</h2>
        <p className="text-slate-400 font-bold text-xs mt-4 px-6 uppercase tracking-widest leading-loose">Precision Vehicle Maintenance Tracking</p>
      </div>
      <div className="space-y-4 pb-12 flex flex-col items-center w-full">
        <div id="googleBtn" className="w-full flex justify-center"></div>
        
        <button onClick={() => setShowEmailForm(true)} className="w-full py-5 border-2 border-slate-100 rounded-full flex items-center justify-center gap-3 font-black text-slate-600 active:bg-slate-50 transition-colors uppercase text-xs tracking-widest">
          <Mail className="w-5 h-5 text-indigo-500" /> Use Email Address
        </button>

        <button onClick={() => onEmailLogin('guest@velominder.my')} className="py-2 text-[10px] font-black text-slate-300 uppercase tracking-[0.2em] hover:text-indigo-600 transition-colors">
          Bypass to Sandbox Mode
        </button>

        <div className="flex flex-col items-center gap-2 pt-4">
          <div className="flex items-center gap-2">
            <CloudSync className="w-3 h-3 text-emerald-500" />
            <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Local-First Storage Enabled</p>
          </div>
          <button onClick={onShowPolicy} className="text-[9px] font-bold text-slate-400 uppercase tracking-wider underline opacity-60">Legal & Privacy Policy</button>
        </div>
      </div>
    </div>
  );
};

// --- Maintenance & Forms ---

const MaintenanceCard = ({ name, category, intervalKm, lastChangedMileage, currentMileage }: any) => {
  const used = currentMileage - lastChangedMileage;
  const health = Math.max(0, Math.min(100, (1 - used / intervalKm) * 100));
  const isBad = health <= 15;
  const isPerfect = health >= 100;

  return (
    <div className={`bg-white p-6 rounded-[2.5rem] border transition-all duration-700 relative ${isPerfect ? 'emerald-glow border-emerald-500/30' : 'border-slate-100 shadow-sm'}`}>
      <div className="flex items-center gap-4 mb-5">
        <div className={`w-14 h-14 rounded-2xl flex items-center justify-center ${isPerfect ? 'bg-emerald-50 text-emerald-500' : isBad ? 'bg-red-50 text-red-500' : 'bg-slate-50 text-slate-900'}`}><Wrench className="w-6 h-6" /></div>
        <div className="flex-1">
          <h4 className="font-black text-slate-900 text-sm uppercase tracking-tight">{name}</h4>
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
            {isPerfect ? 'Condition: Optimum' : `Interval: ${intervalKm.toLocaleString()} KM`}
          </p>
        </div>
        <div className="text-right">
          <p className={`text-2xl font-black leading-none ${isPerfect ? 'text-emerald-600' : isBad ? 'text-red-600' : 'text-slate-900'}`}>{Math.round(health)}<span className="text-xs ml-0.5">%</span></p>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-3">
         <div className="bg-slate-50/80 p-4 rounded-2xl border border-slate-100">
            <p className="text-[8px] font-black text-slate-400 uppercase mb-1">Previous Service</p>
            <p className="text-xs font-black text-slate-700">{lastChangedMileage.toLocaleString()} <span className="text-[9px] opacity-40">KM</span></p>
         </div>
         <div className="bg-slate-50/80 p-4 rounded-2xl border border-slate-100">
            <p className="text-[8px] font-black text-slate-400 uppercase mb-1">Estimated Next</p>
            <p className={`text-xs font-black ${isPerfect ? 'text-emerald-600' : isBad ? 'text-red-600' : 'text-slate-700'}`}>{(lastChangedMileage + intervalKm).toLocaleString()} <span className="text-[9px] opacity-40">KM</span></p>
         </div>
      </div>
    </div>
  );
};

const AddLogModal = ({ car, suggestions, onAdd, onCancel }: any) => {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [showDatePicker, setShowDatePicker] = useState(false);

  const oilLabel = car.type === VehicleType.MOTORCYCLE ? "Engine Oil" : "Engine Oil";
  // Actually both use "Engine Oil" in the UI usually, but let's be safe.
  const mainOilItem = "Engine Oil";

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-6 animate-in zoom-in duration-300">
      <div className="bg-white w-full max-w-sm rounded-[3.5rem] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        <div className="p-10 pb-6 border-b border-slate-100 flex items-center justify-between">
          <h2 className="text-2xl font-black text-slate-900 uppercase tracking-tight">Key-in Service</h2>
          <button onClick={onCancel} className="p-3 bg-slate-100 rounded-full active:scale-90 transition-transform"><X className="w-5 h-5" /></button>
        </div>
        <div className="flex-1 overflow-y-auto p-10 pt-4 space-y-8 hide-scrollbar">
          <div className="space-y-6">
            <div>
              <label className="label">Service Date</label>
              <button onClick={() => setShowDatePicker(true)} className="input flex items-center justify-between group h-16">
                <span className="font-black text-slate-900 text-lg">{selectedDate}</span>
                <Calendar className="w-6 h-6 text-indigo-600" />
              </button>
            </div>
            <div>
              <label className="label">Odometer Reading (KM)</label>
              <input type="number" id="logMileage" defaultValue={car.currentMileage} className="input h-16 text-2xl font-black text-indigo-600" />
            </div>
            <div>
              <label className="label">Notes & Workshop</label>
              <textarea id="logDesc" rows={2} className="input min-h-[100px]" placeholder="e.g. Shell Semi 10W-40, New Oil Filter" />
            </div>
            <div>
              <label className="label">Items Serviced</label>
              <div className="grid grid-cols-2 gap-2">
                {[mainOilItem, ...car.maintenanceItems.map((i: any) => i.name)].map(item => {
                  const isSug = suggestions.includes(item);
                  return (
                    <label key={item} className={`flex items-center gap-2 p-4 border-2 rounded-2xl cursor-pointer transition-all ${isSug ? 'bg-indigo-50 border-indigo-600' : 'bg-slate-50 border-slate-100'}`}>
                      <input type="checkbox" name="logItems" value={item} defaultChecked={isSug} className="w-4 h-4 text-indigo-600 rounded" />
                      <span className="text-[10px] font-black text-slate-700 uppercase truncate">{item}</span>
                    </label>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
        <div className="p-10 border-t border-slate-100 bg-slate-50/50">
           <button onClick={() => {
             const mil = parseInt((document.getElementById('logMileage') as HTMLInputElement).value);
             const items = Array.from(document.getElementsByName('logItems') as NodeListOf<HTMLInputElement>).filter(cb => cb.checked).map(cb => cb.value);
             onAdd({ date: selectedDate, mileage: mil, description: (document.getElementById('logDesc') as HTMLTextAreaElement).value, itemsChanged: items });
           }} className="w-full py-6 bg-slate-900 text-white rounded-[2rem] font-black text-sm uppercase shadow-2xl active:scale-95 transition-transform flex items-center justify-center gap-3">
             <CloudSync className="w-5 h-5" /> Commit to Vault
           </button>
        </div>
      </div>
      {showDatePicker && <DatePickerModal initialDate={selectedDate} onSelect={setSelectedDate} onClose={() => setShowDatePicker(false)} />}
    </div>
  );
};

// --- Modals & Overlays ---

const TabButton = ({ active, onClick, icon, label }: any) => (
  <button onClick={onClick} className={`flex flex-col items-center gap-1.5 transition-all duration-300 ${active ? 'text-indigo-600 scale-110' : 'text-slate-300'}`}>
    {React.cloneElement(icon, { className: 'w-6 h-6' })}
    <span className="text-[9px] font-black uppercase tracking-widest">{label}</span>
  </button>
);

const GarageModal = ({ user, cars, activeCarId, canInstall, onInstall, onSelect, onDelete, onAdd, onCancel, onSignOut, onShowPolicy }: any) => (
  <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[100] flex items-end animate-in slide-in-from-bottom duration-500">
    <div className="w-full bg-white rounded-t-[4rem] p-10 pb-12 space-y-6 shadow-2xl">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-3xl font-black text-slate-900 uppercase tracking-tighter">My Garage</h2>
        <button onClick={onCancel} className="p-3 bg-slate-50 rounded-full"><X className="w-6 h-6" /></button>
      </div>
      
      <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-[2rem] border border-slate-100 mb-4">
         <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-indigo-600 shadow-sm">
           {user?.picture ? <img src={user.picture} className="w-full h-full rounded-2xl object-cover" /> : <User className="w-6 h-6" />}
         </div>
         <div>
           <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Active Operator</p>
           <h4 className="font-bold text-slate-800">{user?.name}</h4>
         </div>
      </div>

      <div className="max-h-[35vh] overflow-y-auto space-y-3 hide-scrollbar">
        {cars.map((c: any) => (
          <div key={c.id} className="flex gap-2">
            <button onClick={() => onSelect(c.id)} className={`flex-1 flex items-center gap-5 p-6 rounded-[2rem] border-2 transition-all duration-300 ${activeCarId === c.id ? 'border-indigo-600 bg-indigo-50/50' : 'border-slate-100'}`}>
              {c.type === VehicleType.MOTORCYCLE ? (
                <Bike className={`w-8 h-8 ${activeCarId === c.id ? 'text-indigo-600' : 'text-slate-300'}`} />
              ) : (
                <CarIcon className={`w-8 h-8 ${activeCarId === c.id ? 'text-indigo-600' : 'text-slate-300'}`} />
              )}
              <div className="text-left"><p className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1.5">{c.plateNumber}</p><h4 className="font-black text-slate-900 text-lg uppercase tracking-tight">{c.model}</h4></div>
            </button>
            <button onClick={() => onDelete(c.id)} className="w-16 bg-red-50 text-red-500 rounded-[2rem] flex items-center justify-center active:bg-red-100 transition-colors"><Trash2 className="w-6 h-6" /></button>
          </div>
        ))}
        <button onClick={onAdd} className="w-full py-6 border-2 border-dashed border-slate-200 rounded-[2rem] text-slate-400 font-black uppercase tracking-[0.2em] text-[10px] active:bg-slate-50 transition-colors">+ Register Vehicle</button>
      </div>
      <div className="flex flex-col gap-3 pt-6 border-t border-slate-100">
        {canInstall && (
          <button onClick={onInstall} className="w-full py-5 bg-indigo-600 text-white rounded-[1.5rem] font-black uppercase text-xs flex items-center justify-center gap-3 shadow-xl">
            <Download className="w-5 h-5" /> Install Application
          </button>
        )}
        <button onClick={onSignOut} className="flex items-center justify-center gap-2 py-4 text-red-400 font-black text-[10px] uppercase tracking-widest active:bg-red-50 rounded-2xl transition-colors"><LogOut className="w-4 h-4" /> Purge Local Profile</button>
      </div>
    </div>
  </div>
);

const UpdateMileageModal = ({ car, suggestionsCount, onUpdate, onCancel }: any) => (
  <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-6 animate-in zoom-in duration-300">
    <div className="bg-white w-full max-w-sm rounded-[3.5rem] shadow-2xl p-10 space-y-8">
      <div className="text-center">
        <div className="w-20 h-20 bg-indigo-50 rounded-[2.5rem] flex items-center justify-center text-indigo-600 mx-auto mb-6 shadow-sm"><Gauge className="w-10 h-10" /></div>
        <h3 className="text-2xl font-black text-slate-900 uppercase tracking-tight">Sync Odometer</h3>
        <p className="text-[10px] font-bold text-slate-400 mt-2 uppercase tracking-widest px-4">Enter current reading from your instrument cluster</p>
      </div>
      <input type="number" id="newMileageInput" autoFocus defaultValue={car.currentMileage} className="input text-center text-4xl font-black py-8 h-20 text-indigo-600" />
      <div className="flex gap-4 pt-2">
         <button onClick={onCancel} className="flex-1 py-5 bg-slate-100 text-slate-500 rounded-[1.5rem] font-black uppercase text-[10px]">Back</button>
         <button onClick={() => {
           const val = parseInt((document.getElementById('newMileageInput') as HTMLInputElement).value);
           if (val >= car.currentMileage) onUpdate(val); else alert("Odometer cannot go backward.");
         }} className="flex-[2] py-5 bg-slate-900 text-white rounded-[1.5rem] font-black uppercase text-xs shadow-2xl active:scale-95 transition-transform flex items-center justify-center gap-2">
            Update Reading <ChevronRightIcon className="w-4 h-4" />
         </button>
      </div>
    </div>
  </div>
);

const DatePickerModal = ({ initialDate, onSelect, onClose }: { initialDate: string, onSelect: (date: string) => void, onClose: () => void }) => {
  const [currentMonth, setCurrentMonth] = useState(new Date(initialDate));
  const daysInMonth = (date: Date) => new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  const startDayOfMonth = (date: Date) => new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  const changeMonth = (offset: number) => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + offset, 1));
  const monthYearStr = currentMonth.toLocaleString('default', { month: 'long', year: 'numeric' });

  const renderDays = () => {
    const totalDays = daysInMonth(currentMonth);
    const firstDay = startDayOfMonth(currentMonth);
    const cells = [];
    for (let i = 0; i < firstDay; i++) cells.push(<div key={`empty-${i}`} className="h-10 w-full"></div>);
    for (let day = 1; day <= totalDays; day++) {
      const dateStr = `${currentMonth.getFullYear()}-${String(currentMonth.getMonth() + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      const isSelected = initialDate === dateStr;
      cells.push(
        <button key={day} onClick={() => { onSelect(dateStr); onClose(); }} className="flex flex-col items-center justify-center h-10 relative">
          <div className={`w-9 h-9 rounded-xl flex items-center justify-center text-xs font-black transition-all ${isSelected ? 'bg-indigo-600 text-white shadow-lg scale-110' : 'text-slate-600 hover:bg-slate-100'}`}>
            {day}
          </div>
        </button>
      );
    }
    return cells;
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[250] flex items-center justify-center p-6 animate-in zoom-in duration-300">
      <div className="bg-white w-full max-w-[340px] rounded-[3rem] shadow-2xl p-8 flex flex-col">
        <div className="flex items-center justify-between mb-6">
          <h4 className="font-black text-slate-900 uppercase text-sm tracking-tight">{monthYearStr}</h4>
          <div className="flex gap-2">
            <button onClick={() => changeMonth(-1)} className="p-2 bg-slate-50 rounded-xl text-slate-400 hover:text-indigo-600 transition-colors"><ChevronLeft className="w-5 h-5" /></button>
            <button onClick={() => changeMonth(1)} className="p-2 bg-slate-50 rounded-xl text-slate-400 hover:text-indigo-600 transition-colors"><ChevronRight className="w-5 h-5" /></button>
          </div>
        </div>
        <div className="grid grid-cols-7 gap-y-1 text-center mb-4">
          {['S','M','T','W','T','F','S'].map((d, i) => <div key={i} className="text-[10px] font-black text-slate-300 uppercase py-2">{d}</div>)}
          {renderDays()}
        </div>
        <button onClick={onClose} className="mt-2 w-full py-4 bg-slate-100 text-slate-500 rounded-[1.5rem] font-black uppercase text-[10px] active:bg-slate-200">Cancel</button>
      </div>
    </div>
  );
};

const ServiceCalendarModal = ({ logs, onClose }: { logs: MaintenanceLog[], onClose: () => void }) => {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const logDates = useMemo(() => new Set(logs.map(log => log.date)), [logs]);
  const daysInMonth = (date: Date) => new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  const startDayOfMonth = (date: Date) => new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  const changeMonth = (offset: number) => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + offset, 1));
  const monthYearStr = currentMonth.toLocaleString('default', { month: 'long', year: 'numeric' });

  const renderDays = () => {
    const totalDays = daysInMonth(currentMonth);
    const firstDay = startDayOfMonth(currentMonth);
    const cells = [];
    for (let i = 0; i < firstDay; i++) cells.push(<div key={`empty-${i}`} className="h-12 w-full"></div>);
    for (let day = 1; day <= totalDays; day++) {
      const dateStr = `${currentMonth.getFullYear()}-${String(currentMonth.getMonth() + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      const hasLog = logDates.has(dateStr);
      cells.push(
        <div key={day} className="flex flex-col items-center justify-center h-12 relative group">
          <div className={`w-11 h-11 rounded-2xl flex items-center justify-center text-xs font-black transition-all ${hasLog ? 'bg-indigo-600 text-white shadow-xl scale-110' : 'text-slate-600'}`}>{day}</div>
          {hasLog && <div className="absolute -bottom-1 w-1 h-1 bg-indigo-600 rounded-full"></div>}
        </div>
      );
    }
    return cells;
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[200] flex items-center justify-center p-6 animate-in zoom-in duration-300">
      <div className="bg-white w-full max-w-sm rounded-[3.5rem] shadow-2xl p-10 flex flex-col">
        <div className="flex items-center justify-between mb-8"><h3 className="text-2xl font-black text-slate-900 uppercase tracking-tighter">Timeline</h3><button onClick={onClose} className="p-3 bg-slate-50 rounded-full"><X className="w-5 h-5" /></button></div>
        <div className="flex items-center justify-between mb-6 px-1">
          <h4 className="font-black text-slate-900 uppercase tracking-widest text-xs">{monthYearStr}</h4>
          <div className="flex gap-2">
            <button onClick={() => changeMonth(-1)} className="p-2 bg-slate-50 rounded-xl text-slate-400"><ChevronLeft className="w-5 h-5" /></button>
            <button onClick={() => changeMonth(1)} className="p-2 bg-slate-50 rounded-xl text-slate-400"><ChevronRight className="w-5 h-5" /></button>
          </div>
        </div>
        <div className="grid grid-cols-7 gap-y-2 text-center mb-6">{['S','M','T','W','T','F','S'].map((d, i) => <div key={i} className="text-[10px] font-black text-slate-300 uppercase">{d}</div>)}{renderDays()}</div>
        <button onClick={onClose} className="w-full py-5 bg-slate-900 text-white rounded-[1.5rem] font-black uppercase text-xs mt-4 shadow-2xl active:scale-95 transition-transform">Done</button>
      </div>
    </div>
  );
};

const PrivacyPolicyModal = ({ onCancel }: any) => (
  <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[200] flex items-center justify-center p-6 animate-in zoom-in duration-200">
    <div className="bg-white w-full max-w-sm rounded-[3.5rem] shadow-2xl p-10 max-h-[80vh] flex flex-col">
      <div className="flex items-center justify-between mb-8 flex-shrink-0"><h3 className="text-2xl font-black text-slate-900 uppercase tracking-tighter">Security</h3><button onClick={onCancel} className="p-3 bg-slate-50 rounded-full"><X className="w-5 h-5" /></button></div>
      <div className="flex-1 overflow-y-auto pr-2 space-y-6 text-slate-600 text-[10px] font-bold uppercase leading-relaxed hide-scrollbar">
        <section><h4 className="text-indigo-600 mb-2 font-black">Zero-Knowledge Storage</h4><p>Your vehicle logs are currently stored exclusively in your browser's LocalStorage. We do not access your personal mileage data without explicit cloud sync consent.</p></section>
        <section><h4 className="text-indigo-600 mb-2 font-black">Educational Tool</h4><p>Velominder is an advisory aid. Always refer to your car's owner manual for official service requirements.</p></section>
      </div>
      <button onClick={onCancel} className="w-full py-5 bg-slate-900 text-white rounded-[1.5rem] font-black uppercase text-xs mt-8 shadow-xl">Dismiss</button>
    </div>
  </div>
);

const Onboarding = ({ onComplete, onCancel }: any) => {
  const [step, setStep] = useState(1);
  const [vehicleType, setVehicleType] = useState<VehicleType>(VehicleType.CAR);
  const [brand, setBrand] = useState('');
  const [model, setModel] = useState('');
  const [plate, setPlate] = useState('');
  const [km, setKm] = useState(0);
  const [oil, setOil] = useState<OilType>(OilType.FULL_5W30);
  const [loading, setLoading] = useState(false);
  
  // Motorcycle specific
  const [motoType, setMotoType] = useState<MotorcycleType>(MotorcycleType.CUB);
  const [cc, setCc] = useState(110);
  const [isCarbureted, setIsCarbureted] = useState(true);

  useEffect(() => {
    if (vehicleType === VehicleType.MOTORCYCLE) {
      setOil(motoType === MotorcycleType.SCOOTER ? OilType.SCOOTER_SEMI_10W40 : OilType.MOTO_SEMI_10W40);
    } else {
      setOil(OilType.FULL_5W30);
    }
  }, [vehicleType, motoType]);

  const finish = async () => {
    setLoading(true);
    const extraInfo = vehicleType === VehicleType.MOTORCYCLE 
      ? `${motoType} ${cc}cc ${isCarbureted ? 'Carbureted' : 'Fuel Injected'}`
      : '';
    const smartItems = await getSmartMaintenanceItems(vehicleType, brand, model, 2024, extraInfo);
    
    const defaultItems = vehicleType === VehicleType.MOTORCYCLE ? MOTO_DEFAULT_MAINTENANCE : DEFAULT_MAINTENANCE;
    
    onComplete({
      id: crypto.randomUUID(), 
      ownerName: 'User', 
      plateNumber: plate, 
      type: vehicleType,
      brand, 
      model, 
      year: 2024,
      currentMileage: km, 
      lastOilChangeMileage: km, 
      oilType: oil,
      motorcycleType: vehicleType === VehicleType.MOTORCYCLE ? motoType : undefined,
      engineCapacity: vehicleType === VehicleType.MOTORCYCLE ? cc : undefined,
      isCarbureted: vehicleType === VehicleType.MOTORCYCLE ? isCarbureted : undefined,
      maintenanceItems: (smartItems || defaultItems).map((i: any) => ({
        id: crypto.randomUUID(), 
        name: i.name, 
        intervalKm: i.intervalKm || i.interval,
        lastChangedMileage: km, 
        category: i.category, 
        importance: i.importance || 'normal'
      }))
    });
  };

  return (
    <div className="h-full bg-slate-900 p-8 flex flex-col justify-center animate-in zoom-in duration-700">
      <div className="bg-white p-10 rounded-[3.5rem] shadow-2xl relative max-h-[90vh] flex flex-col">
        <h2 className="text-2xl font-black text-slate-900 uppercase text-center mb-8 flex-shrink-0 tracking-tighter">Register Vehicle</h2>
        <div className="flex-1 overflow-y-auto hide-scrollbar pr-1">
          {step === 1 ? (
            <div className="space-y-6">
               <div className="flex gap-2">
                 <button 
                   onClick={() => setVehicleType(VehicleType.CAR)}
                   className={`flex-1 py-4 rounded-2xl border-2 font-black uppercase text-[10px] flex items-center justify-center gap-2 transition-all ${vehicleType === VehicleType.CAR ? 'border-indigo-600 bg-indigo-50 text-indigo-600' : 'border-slate-100 text-slate-400'}`}
                 >
                   <CarIcon className="w-4 h-4" /> Car
                 </button>
                 <button 
                   onClick={() => setVehicleType(VehicleType.MOTORCYCLE)}
                   className={`flex-1 py-4 rounded-2xl border-2 font-black uppercase text-[10px] flex items-center justify-center gap-2 transition-all ${vehicleType === VehicleType.MOTORCYCLE ? 'border-indigo-600 bg-indigo-50 text-indigo-600' : 'border-slate-100 text-slate-400'}`}
                 >
                   <Bike className="w-4 h-4" /> Motorcycle
                 </button>
               </div>

               <div><label className="label">Vehicle Plate</label><input value={plate} onChange={e => setPlate(e.target.value.toUpperCase())} className="input uppercase" placeholder="E.G. VAD 123" /></div>
               
               <div>
                 <label className="label">Brand</label>
                 <select value={brand} onChange={e => setBrand(e.target.value)} className="input">
                   <option value="">SELECT BRAND</option>
                   {(vehicleType === VehicleType.CAR ? CAR_BRANDS : MOTO_BRANDS).map(b => <option key={b} value={b}>{b}</option>)}
                 </select>
               </div>

               <div><label className="label">Model Name</label><input value={model} onChange={e => setModel(e.target.value)} className="input uppercase" placeholder={vehicleType === VehicleType.CAR ? "E.G. MYVI" : "E.G. Y15ZR"} /></div>

               {vehicleType === VehicleType.MOTORCYCLE && (
                 <div className="space-y-6 pt-2 animate-in fade-in slide-in-from-top duration-500">
                   <div>
                     <label className="label">Motorcycle Type</label>
                     <div className="grid grid-cols-3 gap-2">
                       {Object.values(MotorcycleType).map(t => (
                         <button 
                           key={t} 
                           onClick={() => setMotoType(t)}
                           className={`py-3 rounded-xl border-2 font-black uppercase text-[8px] transition-all ${motoType === t ? 'border-indigo-600 bg-indigo-50 text-indigo-600' : 'border-slate-100 text-slate-400'}`}
                         >
                           {t}
                         </button>
                       ))}
                     </div>
                   </div>
                   <div className="grid grid-cols-2 gap-4">
                     <div>
                       <label className="label">Engine CC</label>
                       <input type="number" value={cc} onChange={e => setCc(parseInt(e.target.value))} className="input" placeholder="110" />
                     </div>
                     <div>
                       <label className="label">Fuel System</label>
                       <div className="flex bg-slate-50 rounded-xl p-1 border border-slate-100">
                         <button onClick={() => setIsCarbureted(true)} className={`flex-1 py-2 rounded-lg text-[8px] font-black uppercase transition-all ${isCarbureted ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-400'}`}>Carb</button>
                         <button onClick={() => setIsCarbureted(false)} className={`flex-1 py-2 rounded-lg text-[8px] font-black uppercase transition-all {!isCarbureted ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-400'}`}>Injection</button>
                       </div>
                     </div>
                   </div>
                 </div>
               )}
            </div>
          ) : (
            <div className="space-y-8">
              <div><label className="label">Current Odometer (KM)</label><input type="number" value={km} onChange={e => setKm(parseInt(e.target.value))} className="input h-16 text-2xl font-black text-indigo-600" /></div>
              <div>
                  <label className="label">Engine Oil Preference</label>
                  <div className="grid grid-cols-1 gap-3">
                      {Object.entries(OIL_PROFILES)
                        .filter(([type]) => {
                          if (vehicleType === VehicleType.CAR) return !type.startsWith('MOTO') && !type.startsWith('SCOOTER');
                          if (motoType === MotorcycleType.SCOOTER) return type.startsWith('SCOOTER');
                          return type.startsWith('MOTO');
                        })
                        .map(([t, profile]) => (
                        <button key={t} onClick={() => setOil(t as OilType)} className={`flex flex-col items-start p-5 border-2 rounded-[1.5rem] transition-all duration-300 ${oil === t ? 'border-indigo-600 bg-indigo-50/50' : 'border-slate-100'}`}>
                          <span className={`text-[11px] font-black uppercase tracking-tight ${oil === t ? 'text-indigo-600' : 'text-slate-900'}`}>{t}</span>
                          <span className="text-[9px] font-bold text-slate-400 uppercase mt-1 tracking-widest">{profile.intervalKm.toLocaleString()} KM Interval</span>
                        </button>
                      ))}
                  </div>
              </div>
            </div>
          )}
        </div>
        <div className="pt-8 flex-shrink-0">
          {step === 1 ? (
            <button disabled={!plate || !brand || !model} onClick={() => setStep(2)} className="w-full py-6 bg-slate-900 text-white rounded-[2rem] font-black uppercase text-sm shadow-2xl active:scale-95 transition-transform flex items-center justify-center gap-2">Next Step <ChevronRightIcon className="w-5 h-5" /></button>
          ) : (
            <div className="flex gap-4">
               <button onClick={() => setStep(1)} className="flex-1 py-6 bg-slate-100 text-slate-600 rounded-[1.5rem] font-black uppercase text-[10px]">Back</button>
               <button onClick={finish} disabled={loading} className="flex-[2] py-6 bg-indigo-600 text-white rounded-[1.5rem] font-black uppercase text-xs shadow-2xl flex items-center justify-center active:scale-95 transition-transform">{loading ? <Loader2 className="animate-spin" /> : `Register ${vehicleType === VehicleType.CAR ? 'Car' : 'Bike'}`}</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default App;
